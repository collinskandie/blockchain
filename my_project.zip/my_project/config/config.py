   # Example for Ethereum
BLOCKCHAIN_URL = "http://localhost:8545"  # Ethereum node URL
CONTRACT_ADDRESS = "0x123456789ABCDEF"  # Smart contract address
CONTRACT_ABI = [...]  # ABI of the smart contract
