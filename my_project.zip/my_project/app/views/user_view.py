class UserView:
    def display_user_info(self, user_info):
        # Display user information on the user interface
        print(user_info)

    def input_username(self):
        # Prompt the user for input (e.g., username)
        return input("Enter username: ")

    def input_email(self):
        # Prompt the user for input (e.g., email)
        return input("Enter email: ")
