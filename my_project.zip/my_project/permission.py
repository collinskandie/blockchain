class Permission:
    def __init__(self, name):
        self.name = name

# Permissions can be defined as instances of this class or simply as strings
